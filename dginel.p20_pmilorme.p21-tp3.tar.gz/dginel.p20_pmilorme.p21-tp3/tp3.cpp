/********************************************************************
 * 
    TP3 : Vision par ordinateur
    Auteurs : DORLEON Ginel et MILORME Pierre Rubens
 *   
*********************************************************************
*/

#include "opencv2/video/tracking.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <bits/basic_string.h>
#include <map>
#include "fonctions.h"

using namespace cv;
using namespace std;



int main(int argc, char** argv) {
    
	int nbFrameCaptureParSeconde = atoi(argv[1]);//5
	int seuilDifference = atoi(argv[2]);//60
	int seuil_noise=atoi(argv[3]); //30
	int seuilCorrespondant=atoi(argv[4]); //80
	String  nomVideo=argv[5];
	int nbFrame = 100;
    
	//Nombre de parametres state: x, y, vx, vy
	int nbParamState = 4;
	int nbParamMesure = 4; //x, y, vx, vy sont mesures


	//Ouverture du fichier video
	VideoCapture videoCap(nomVideo);
	if (!videoCap.isOpened()) {
		cout << "La video ne peut pas s'ouvrir : " << nomVideo <<  "..." << endl;
		return (EXIT_FAILURE);
	}


	//Recuperer Frame-Rate - le nombre d'images par seconde du video
	int frameRate = videoCap.get(CV_CAP_PROP_FPS);

	//Calcul de la frequence de capture des images de la video
	int dureeCapture = frameRate / nbFrameCaptureParSeconde;

	//La taille de la video
	int w = videoCap.get(CV_CAP_PROP_FRAME_WIDTH);
	int h = videoCap.get(CV_CAP_PROP_FRAME_HEIGHT);

	//Declarer des images background, mouvement
	Mat imgBG;
	Mat imgMvt;

	//Declarer des matrices floating point pour des images: image capturee, background et mouvement
	Mat matriceBG;
	Mat matriceFrame;
	Mat matriceMvt;
	//Declarer une image qui contient tous les traces de tous les objets en mouvement dans le video
	Mat imgSuiviMouvement;

	//Vecteur des objets en mouvement du frame courant
	vector<BoiteEnglobante> objetCourants;
	objetCourants.clear();
	//Vecteur des objets en mouvement du frame precedent
	vector<BoiteEnglobante> previousBoiteObjets;
	previousBoiteObjets.clear();

	//List Kalmal filter des objets en mouvement
	map<int, KalmanFilter> listKalmanFilter;
	listKalmanFilter.clear();

	//numero des images de mouvement
	int index = 0;
	//Index du frame courant
	int numFrameCourant = -1;

	//Initialiser des fenetres pour afficher des resultats
	namedWindow("Video_BoiteEnglobante", 1);

	namedWindow("Image Mouvement", 1);
	namedWindow("Suivi", 1);
	// Construction bg
	construireBackground(nomVideo, imgBG, nbFrame);
	namedWindow("Image Background", 1);
	imshow("Image Background", imgBG);
	while (1){
		Mat frame;
		//Recuperer une nouvelle image
		//En fonction du video, image capturee est en couleur ou en niveau de gris
		videoCap >> frame;
		if (!frame.data) {
			break;
		}
		numFrameCourant = numFrameCourant + 1;

		//Verifier si on capture cette image ou non
		if (numFrameCourant % dureeCapture == 0){
			if (numFrameCourant == 0) {
				//Initialiser des images et des matrices
				//Image en niveau de gris pour mouvement
				imgMvt = Mat::zeros(frame.size(), CV_8UC1);
				imgSuiviMouvement = Mat::zeros(frame.size(), CV_8UC3);
				imwrite("suivi.png", imgSuiviMouvement);
				//Transformer l'image capturee en niveau de gris
				cvtColor(frame, imgMvt, CV_BGR2GRAY);
				//Transformer des images en des matrices
				imgBG.convertTo(matriceBG, CV_32FC1);
				imgMvt.convertTo(matriceMvt, CV_32FC1);
				imgMvt.convertTo(matriceFrame, CV_32FC1);
				index ++;
			}
			else {
				//Detection du mouvement 
				cvtColor(frame, imgMvt, CV_BGR2GRAY);
				imgMvt.convertTo(matriceFrame, CV_32FC1);
				imgBG.convertTo(matriceBG, CV_32FC1);
				//Decter le mouvement en utilisant la difference entre
				//l'image background et l'image capturee
				absdiff(matriceFrame, matriceBG, matriceMvt);
				threshold(matriceMvt, imgMvt, seuilDifference, 255.0, CV_THRESH_BINARY);
				Mat imgTraite;
				imgMvt.convertTo(imgTraite, CV_8UC1);
				pretraitementDetection(imgTraite, seuil_noise);
				//Determiner des boites englobantes minimales
				objetCourants = determinerBoite(imgTraite, seuil_noise);
				//Suivi mouvement
				//Si c'est le premier frame
				if ((previousBoiteObjets.size() == 0) && (objetCourants.size() > 0)) {
					//Initialiser les filtres pour tous les objets
					kalmanFilter(listKalmanFilter, objetCourants, 4, 4, w, h);
					previousBoiteObjets = objetCourants;
				}
				else
				{ //Les frames suivants
					//Ouvrir l'image qui contient tous les traces de tous les objets en mouvement
					imgSuiviMouvement = imread("suivi.png", -1);
					for (int i = 0; i < (int)previousBoiteObjets.size(); i++) {
						//1. Faire la prediction
						Mat predictionMat = listKalmanFilter[previousBoiteObjets[i].numObjet].predict();

						stringstream ss;
						ss << "objet_suivi/objet_" << previousBoiteObjets[i].numObjet << ".png";
						string fileName = ss.str();
						Mat imgSuivi = imread(fileName, -1);

						//Dessiner le trajectoire de prediction
						dessiner_croix(imgSuivi, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
						dessiner_croix(imgSuiviMouvement, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));

						//2. Chercher des correspondances
						int correspondance = rechercheCorrespondance(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0), objetCourants, seuilCorrespondant);
						if (correspondance != -1)
						{//Si trouver l'objet correspondant
							//Assigner l'index correspondant
							objetCourants[correspondance].numObjet = previousBoiteObjets[i].numObjet;
							//Faire le mesurement
							Mat mesurement = Mat::zeros(nbParamMesure, 1, CV_32FC1);
							//La position observee
							mesurement.at<float>(0,0) = (objetCourants[correspondance].p1.x + objetCourants[correspondance].p2.x) / 2;
							mesurement.at<float>(1,0) = (objetCourants[correspondance].p1.y + objetCourants[correspondance].p2.y) / 2;
							//La vitesse calculee
							float vx = 0;
							float vy = 0;
							vx = ((objetCourants[correspondance].p1.x + objetCourants[correspondance].p2.x) / 2) -
									((previousBoiteObjets[i].p1.x + previousBoiteObjets[i].p2.x) / 2);
							vy = ((objetCourants[correspondance].p1.y + objetCourants[correspondance].p2.y) / 2) -
									((previousBoiteObjets[i].p1.y + previousBoiteObjets[i].p2.y) / 2);
							mesurement.at<float>(2,0) = vx;
							mesurement.at<float>(3,0) = vy;
							//Faire la correction
							Mat correctionMat = listKalmanFilter[previousBoiteObjets[i].numObjet].correct(mesurement);

							//Afficher et enregistrer les resultats suivi du mouvement
							//Dessiner le trajectoire de mesurement
							dessiner_cercle(imgSuivi, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
							dessiner_cercle(imgSuiviMouvement, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
							//Dessiner le trajectoire de correction
							dessiner_carre(imgSuivi, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
							dessiner_carre(imgSuiviMouvement, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
							//Dessiner les trois trajectoire sur le frame courant
							dessiner_croix(frame, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
							//Dessiner le trajectoire de mesurement
							dessiner_cercle(frame, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
							//Dessiner le trajectoire de correction
							dessiner_carre(frame, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
							//Enregistrer l'image suivi pour cet objet
							imwrite(fileName, imgSuivi);
						}
					}
					//3. Initialiser Kalman Filter pour de nouveaux objets (ce qui ayant numObjet = -1)
					kalmanFilter(listKalmanFilter, objetCourants, nbParamState, nbParamMesure, w, h);
					previousBoiteObjets = objetCourants;
				}

				//Dessiner des boites sur l'image correspondante
				dessinerBoite(frame, objetCourants);
				//Ajouter les noms des objets en mouvement dans le frame courant
				for (int i = 0; i < (int)objetCourants.size(); i++) {
					stringstream s;
					s << objetCourants[i].numObjet;
					string text = s.str();
					int fontFace = CV_FONT_HERSHEY_SIMPLEX;
					double fontScale = 0.5;
					int thickness = 1;
					int x = (objetCourants[i].p1.x + objetCourants[i].p2.x) / 2;
					int y = (objetCourants[i].p1.y + objetCourants[i].p2.y) / 2;
					Point textPosition(x,y);
					putText(frame, text, textPosition, fontFace, fontScale, CV_RGB(0, 0, 255), thickness, 8);
				}
				
				//Saving the results
				stringstream ssFileName;
				ssFileName << nomVideo << "_dectection_" << index << ".png";
				string fileNameTmp = ssFileName.str();
				string mouvementFileName = "image_detecte/" + fileNameTmp;
				string frameFileName = "frame/" + fileNameTmp;
				imwrite(mouvementFileName, imgTraite);
				imwrite(frameFileName, frame);
				imwrite("suivi.png", imgSuiviMouvement);
				imshow("Suivi", imgSuiviMouvement);
				imshow("video_boiteEnglobante", frame);
				imshow("image_mouvement", imgTraite);

				index ++;
			}
		}
		waitKey(10);
	}

	return (EXIT_SUCCESS);
}


