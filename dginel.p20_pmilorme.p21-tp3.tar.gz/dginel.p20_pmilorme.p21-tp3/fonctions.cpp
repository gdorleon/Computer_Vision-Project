#include "fonctions.h"


/*
 * Construire l'image background
 */
void construireBackground (string nomVideo, Mat & background,  int nbFrame) {
	VideoCapture videoCap(nomVideo);
	if (!videoCap.isOpened()) {
		cout << "Impossible d'ouvrir la vidéo: " << nomVideo <<  "..." << endl;
		return;
	}
	int w = videoCap.get(CV_CAP_PROP_FRAME_WIDTH);
	int h = videoCap.get(CV_CAP_PROP_FRAME_HEIGHT);
	vector<Mat> sequence;
	int count = -1;
	// int nbFrame = videoCap.get(CV_CAP_PROP_FRAME_COUNT);
	cout <<videoCap.get(CV_CAP_PROP_FRAME_COUNT);
	while (true) {
		Mat frame;
		videoCap >> frame;
		if (!frame.data) {
			break;
		}
		count ++;
		//  if ((count >= frameInit) && (count < frameInit + nbFrame)) {
		Mat frameGray;
		cvtColor(frame, frameGray, CV_BGR2GRAY);
		sequence.push_back(frameGray);
		// }
	if (count >=  nbFrame) break;
	}
	//Verifier si nous avons 50 images pour construire le background
	if ((int)sequence.size() < nbFrame) return;
	//Initialiser l'image background
	background = Mat::zeros(h, w, CV_8UC1);
	for (int i = 0; i < background.rows; i++) {
		for (int j = 0; j < background.cols; j++) {
			int nbImage = sequence.size();
			//Mettre en ordre croissant une sequence de pixels
			int * sequencePixel = (int *)malloc(sizeof(int) * nbImage);
			for (int k = 0; k < nbImage; k++) {
				sequencePixel[k] = sequence[k].at<uchar>(i,j);
			}
			for (int k = 0; k < nbImage - 1; k++) {
				for (int l = k + 1; l < nbImage; l++) {
					if (sequencePixel[k] > sequencePixel[l]) {
						int tmp = 0;
						tmp = sequencePixel[k];
						sequencePixel[k] = sequencePixel[l];
						sequencePixel[l] = tmp;
					}
				}
			}
			//Prendre le median de la sequence de pixel
			background.at<uchar>(i,j) = sequencePixel[(nbImage + 1) / 2];
			delete [] sequencePixel;
		}
	}
	//Save image background
	imwrite(nomVideo + "_background.png", background);
}

/*
 * Enlever du bruit, Fermer des trous... pour l'image de detection du mouvement
 */
void pretraitementDetection (Mat &imgTraite, int seuil) {
	//Appliquer Canny pour trouver des contours
	Mat imgMvt = imgTraite.clone();
	Mat imgCanny;
	Canny(imgMvt, imgCanny, 10, 170, 3, false);
	//Enlever du bruit
	Mat imgSansBruit = imgCanny.clone();
	int w = imgCanny.cols & -2;
	int h = imgCanny.rows & -2;
	Size sizeTmp = Size(w/2, h/2);
	Mat tmp = Mat::zeros(sizeTmp, imgCanny.type());
	pyrDown(imgSansBruit, tmp, sizeTmp);
	pyrUp(tmp, imgSansBruit, Size(imgCanny.cols, imgCanny.rows));
	//prendre des composantes connexes par la fonction floodFill()
	Mat imgComposantConnexe = imgSansBruit.clone();
	floodFill(imgComposantConnexe, Point(0,0), Scalar::all(0xFFFFFF));
	//recuperer l'image binaire qui contient des objets en mouvement
	Mat imgConnexe = imgComposantConnexe.clone();
	threshold(imgConnexe, imgConnexe, 254, 255, CV_THRESH_BINARY_INV);
	//Enlever du bruit
	vector< vector<Point> > contours;
	Mat imgContour = imgConnexe.clone();
	findContours(imgContour, contours, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	for (int i = 0; i < (int)contours.size(); i++) {
		//Enlever si le nombre de pixel < seuil
		if ((int)contours[i].size() < seuil) {
			Mat pointMat(contours[i]);
			//Pour chaque contour, determiner le rectangle entourant
			Rect rect = boundingRect(pointMat);
			for (int k = rect.y; k <= rect.y + rect.height; k++) {
				for (int l = rect.x; l <= rect.x + rect.width; l++) {
					imgConnexe.at<uchar>(k,l) = 0;
				}
			}
		}
	}
	//    imwrite("traiter/imgConnexe.png", imgConnexe);
	//Erode et Dilate
	Mat imgErode = imgConnexe.clone();
	erode(imgErode, imgErode, Mat(), Point(-1,-1), 3);
	Mat imgDilate = Mat::zeros(imgErode.size(), imgErode.type());
	dilate(imgErode, imgDilate, Mat(), Point(-1, -1), 1);
	imgTraite = imgDilate.clone();
}

/*
 * Determiner des boites englobantes minimales entourant les objets en mouvement
 */
vector<BoiteEnglobante> determinerBoite(const Mat &currentFrame, int seuil) {
	//Declarer la liste des boites, chacune pour chaque objet en mouvement dans l'image
	vector<BoiteEnglobante> boiteObjets;
	boiteObjets.clear();
	//Chaque contour d'un objet en mouvement est represente par une liste de points
	vector< vector<Point> > contours;
	//Trouver tous les contours dans le frame courant
	Mat imgContour = currentFrame.clone();
	findContours(imgContour, contours, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	for (int i = 0; i < (int)contours.size(); i++) {
		if ((int)contours[i].size() >= seuil) {
			//Transformer le vecteur de points en matrice de points
			Mat pointMat(contours[i]);
			//Pour chaque contour, determiner le rectangle entourant
			Rect rect = boundingRect(pointMat);
			BoiteEnglobante boite;
			boite.p1.x = rect.x;
			boite.p1.y = rect.y;
			boite.p2.x = rect.x + rect.width;
			boite.p2.y = rect.y + rect.height;
			boite.numObjet = -1;//pas encore avoir l'etiquette
			boiteObjets.push_back(boite);
		}
	}
	return boiteObjets;
}

/*
 * Dessiner des boites entourant des objets en mouvement
 */
void dessinerBoite(Mat &currentFrame, vector<BoiteEnglobante> boiteObjets) {
	//Utiliser le vert pour dessiner des boites entourant des objets
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		rectangle(currentFrame, boiteObjets[i].p1, boiteObjets[i].p2, CV_RGB(255, 0, 0), 1);
	}
}

/*
 * Dessiner le trajectoire pour la prediction
 */
void dessiner_croix(Mat &imgSuivi, Point centre, int d, const Scalar& color) {
	//La forme est x pour chaque point
	line(imgSuivi, Point(centre.x - d, centre.y -d), Point(centre.x + d, centre.y + d), color, 1, 0);
	line(imgSuivi, Point(centre.x + d, centre.y -d), Point(centre.x - d, centre.y + d), color, 1, 0);
}

/*
 * Dessiner le trajectoire pour le mesurement
 */
void dessiner_cercle(Mat &imgSuivi, Point centre, int d, const Scalar& color) {
	circle(imgSuivi, centre, d, color, 1, 0);
}

/*
 * Dessiner le trajectoire pour la correction
 */
void dessiner_carre(Mat &imgSuivi, Point centre, int d, const Scalar& color) {
	rectangle(imgSuivi, Point(centre.x - d, centre.y -d), Point(centre.x + d, centre.y + d), color, 1, 0);
}

/*
 * Trouver l'objet correspondant dans le frame suivant
 */
int rechercheCorrespondance(int x, int y, vector<BoiteEnglobante> boiteObjets, int seuil) {
	int correspondanceIndex = -1;
	int min = 1000000;
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		int centreX = (boiteObjets[i].p1.x + boiteObjets[i].p2.x) / 2;
		int centreY = (boiteObjets[i].p1.y + boiteObjets[i].p2.y) / 2;
		//Si le point centre (x,y) de l'objet a rechercher sa correspondance est
		//dans la fenetre
		if ((x >= centreX - seuil) && (x <= centreX + seuil) && (y >= centreY - seuil) && (y <= centreY + seuil)) {
			//Trouver ce qui a la distance minimal par rapport au point centre (centreX, centreY)
			int distance = (centreX - x) * (centreX - x) + (centreY - y) * (centreY - y);
			if (distance < min) {
				min = distance;
				correspondanceIndex = i;
			}
		}
	}
	return correspondanceIndex;
}

/*
 * Initialise les kalman Filter pour des objets en mouvement dans le frame
 */
void kalmanFilter(map<int, KalmanFilter> &listKalmanFilter, vector<BoiteEnglobante> &boiteObjets, int nbParamState, int nbParamMesure, int w, int h) {
	//Pour chaque objet dans la boite, etiqueter et initialiser le filtre kalman
	int maxIndex = -1;
	//Trouver l'index maximal de l'objet dans la liste
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		if (maxIndex < boiteObjets[i].numObjet) {
			maxIndex = boiteObjets[i].numObjet;
		}
	}
	//Etiquette pour des objets ayant numObjet = -1
	//Mesurer deux parametres seulement: x et y
	Mat mesurement = Mat::zeros(nbParamMesure, 1, CV_32FC1);
	//Declarer une image pour contenir tous les traces de tous les objets en mouvement
	Mat imgSuiviMouvement = imread("suivi.png", -1);
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		if (boiteObjets[i].numObjet == -1)
		{   //C'est le nouvel objet, pas ayant le filtre Kalman,
			//on va initialiser un filtre Kalman pour suivre le mouvement de cet objet
			maxIndex++;
			boiteObjets[i].numObjet = maxIndex;
			//Initialiser le filter Kalman
			KalmanFilter kalman(nbParamState, nbParamMesure, 0);
			//Initialiser des matrices
			setIdentity(kalman.transitionMatrix, cvRealScalar(1));
			kalman.transitionMatrix.at<float>(0,2) = 1;
			kalman.transitionMatrix.at<float>(1,3) = 1;
			setIdentity(kalman.processNoiseCov, cvRealScalar(0));
			setIdentity(kalman.measurementNoiseCov, cvRealScalar(0));
			setIdentity(kalman.measurementMatrix, cvRealScalar(1));
			setIdentity(kalman.errorCovPost, cvRealScalar(1));
			//Faire la prediction, pas encore avoir les donnees historiques
			Mat predictionMat = kalman.predict();

			//Faire le mesurement
			//Calculer le point au centre de la boite englobante
			mesurement.at<float>(0,0) = (boiteObjets[i].p2.x + boiteObjets[i].p1.x) / 2;
			mesurement.at<float>(1,0) = (boiteObjets[i].p2.y + boiteObjets[i].p1.y) / 2;
			//La vitesse vx, vy
			mesurement.at<float>(2,0) = 0;
			mesurement.at<float>(3,0) = 0;

			//Faire la correction
			Mat correctionMat = kalman.correct(mesurement);

			//Pour chaque objet, initialiser une image suivi
			Mat imgSuivi;
			stringstream ss;
			ss << "objet_suivi/objet_" << boiteObjets[i].numObjet << ".png";
			string filename = ss.str();
			imgSuivi = imread(filename, -1);
			if (!imgSuivi.data) {
				imgSuivi = Mat::zeros(h, w, CV_8UC3);
			}

			//Dessiner le trajectoire de prediction
			dessiner_croix(imgSuivi, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
			dessiner_croix(imgSuiviMouvement, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
			//Dessiner le trajectoire de mesurement
			dessiner_cercle(imgSuivi, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
			dessiner_cercle(imgSuiviMouvement, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
			//Dessiner le trajectoire de correction
			dessiner_carre(imgSuivi, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
			dessiner_carre(imgSuiviMouvement, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
			//Dessiner text dans l'image suivi de mouvement
			stringstream ssText;
			ssText << boiteObjets[i].numObjet;
			string text = ssText.str();
			int fontFace = CV_FONT_HERSHEY_SIMPLEX;
			double fontScale = 0.5;
			int thickness = 1;
			int x = (boiteObjets[i].p1.x + boiteObjets[i].p2.x) / 2;
			int y = (boiteObjets[i].p1.y + boiteObjets[i].p2.y) / 2;
			Point textPosition(x,y);
			putText(imgSuivi, text, textPosition, fontFace, fontScale, CV_RGB(255, 255, 255), thickness, 8);

			//Enregistrer l'image suivi pour cet objet
			imwrite(filename, imgSuivi);
			//Ajouter le filter kalman a la liste des filtres
			listKalmanFilter[boiteObjets[i].numObjet] = kalman;
		}
	}
	imwrite("suivi.png", imgSuiviMouvement);
}
