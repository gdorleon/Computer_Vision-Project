#ifndef FONCTIONS_H_INCLUDED
#define FONCTIONS_H_INCLUDED


#include "opencv2/video/tracking.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <bits/basic_string.h>
#include <map>

using namespace cv;
using namespace std;

/*
 * Structure de la boite englobante minimale
 */

typedef struct {
	Point p1;
	Point p2;
	//Index de l'objet pour distinguer des objets differents
	int numObjet;
} BoiteEnglobante;

/*
 * Construire l'image background
 */
void construireBackground (string nomVideo, Mat & background,  int nbFrame);

/*
 * Enlever du bruit, Fermer des trous... pour l'image de detection du mouvement
 */
void pretraitementDetection (Mat &imgTraite, int seuil);
/*
 * Determiner des boites englobantes minimales entourant les objets en mouvement
 */
vector<BoiteEnglobante> determinerBoite(const Mat &currentFrame, int seuil);

/*
 * Dessiner des boites entourant des objets en mouvement
 */
void dessinerBoite(Mat &currentFrame, vector<BoiteEnglobante> boiteObjets);

/*
 * Dessiner le trajectoire pour la prediction
 */
void dessiner_croix(Mat &imgSuivi, Point centre, int d, const Scalar& color);

/*
 * Dessiner le trajectoire pour le mesurement */
void dessiner_cercle(Mat &imgSuivi, Point centre, int d, const Scalar& color);
/*
 * Dessiner le trajectoire pour la correction */
void dessiner_carre(Mat &imgSuivi, Point centre, int d, const Scalar& color);
/*
 * Trouver l'objet correspondant dans le frame suivant */
int rechercheCorrespondance(int x, int y, vector<BoiteEnglobante> boiteObjets, int seuil);

/*
 * Initialise les kalman Filter pour des objets en mouvement dans le frame
 */
void kalmanFilter(map<int, KalmanFilter> &listKalmanFilter, vector<BoiteEnglobante> &boiteObjets, int nbParamState, int nbParamMesure, int w, int h);

#endif // FONCTIONS_H_INCLUDED


